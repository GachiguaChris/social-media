import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface AnalyticsCardProps {
  title: string;
  value: string | number;
  change: number;
  icon: React.ReactNode;
}

const AnalyticsCard = ({ title, value, change, icon }: AnalyticsCardProps) => {
  const isPositive = change >= 0;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-gray-500 dark:text-gray-400 text-sm">{title}</span>
        <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
          {icon}
        </div>
      </div>
      
      <div className="mt-4">
        <h3 className="text-2xl font-semibold dark:text-white">{value}</h3>
        <div className="flex items-center mt-2">
          {isPositive ? (
            <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
          )}
          <span className={\`text-sm \${isPositive ? 'text-green-500' : 'text-red-500'}\`}>
            {Math.abs(change)}%
          </span>
          <span className="text-gray-500 dark:text-gray-400 text-sm ml-1">vs last month</span>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsCard;