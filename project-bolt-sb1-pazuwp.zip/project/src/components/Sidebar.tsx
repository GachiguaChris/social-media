import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  Settings, 
  BarChart3,
  MessageSquarePlus
} from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  
  const links = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/compose', icon: MessageSquarePlus, label: 'Compose' },
    { path: '/schedule', icon: Calendar, label: 'Schedule' },
    { path: '/analytics', icon: BarChart3, label: 'Analytics' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="h-screen w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 p-4">
      <div className="flex items-center gap-2 mb-8 px-2">
        <LayoutDashboard className="w-8 h-8 text-blue-600" />
        <span className="text-xl font-bold dark:text-white">SocialDash</span>
      </div>
      
      <nav className="space-y-2">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location.pathname === link.path;
          
          return (
            <Link
              key={link.path}
              to={link.path}
              className={\`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors
                \${isActive 
                  ? 'bg-blue-50 dark:bg-gray-700 text-blue-600 dark:text-blue-400' 
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'}\`
              }
            >
              <Icon className="w-5 h-5" />
              <span>{link.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;