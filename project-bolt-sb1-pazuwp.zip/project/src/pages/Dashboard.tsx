import React from 'react';
import { Users, Share2, MousePointer, BarChart2 } from 'lucide-react';
import AnalyticsCard from '../components/AnalyticsCard';

const Dashboard = () => {
  const analyticsData = [
    {
      title: 'Total Followers',
      value: '24.5K',
      change: 12,
      icon: <Users className="w-5 h-5 text-blue-600" />,
    },
    {
      title: 'Engagement Rate',
      value: '5.2%',
      change: -2.1,
      icon: <Share2 className="w-5 h-5 text-purple-600" />,
    },
    {
      title: 'Click Through',
      value: '12.3K',
      change: 8.3,
      icon: <MousePointer className="w-5 h-5 text-green-600" />,
    },
    {
      title: 'Post Reach',
      value: '89.2K',
      change: 15.6,
      icon: <BarChart2 className="w-5 h-5 text-orange-600" />,
    },
  ];

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold dark:text-white mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {analyticsData.map((data, index) => (
          <AnalyticsCard key={index} {...data} />
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold dark:text-white mb-4">Recent Posts</h2>
          {/* Add recent posts list here */}
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold dark:text-white mb-4">Upcoming Schedule</h2>
          {/* Add upcoming schedule here */}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;