export interface Post {
  id: string;
  content: string;
  platform: 'twitter' | 'facebook' | 'instagram' | 'linkedin';
  scheduledTime: string;
  status: 'draft' | 'scheduled' | 'published';
}

export interface AnalyticsData {
  engagement: number;
  reach: number;
  clicks: number;
  shares: number;
}

export interface Platform {
  name: string;
  connected: boolean;
  analytics: AnalyticsData;
}